function WWTLatLng(lat, lng) {
    this.Dec = lat;
    this.RA = -(lng - 180);
    return;
}

var polys{
'NIR1':[new WWTLatLng(30.360,127.680),new WWTLatLng(30.631,127.681),new WWTLatLng(30.630,128.280),new WWTLatLng(30.361,128.281),new WWTLatLng(30.360,127.680)],